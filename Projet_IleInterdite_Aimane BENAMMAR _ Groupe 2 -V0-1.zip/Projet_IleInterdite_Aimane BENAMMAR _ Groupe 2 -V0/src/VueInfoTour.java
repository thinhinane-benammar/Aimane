import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * Une classe pour repr�senter la zone d'affichage des cellules.
 *
 * JPanel est une classe d'�l�ments graphiques, pouvant comme JFrame contenir
 * d'autres �l�ments graphiques.
 *
 * Cette vue va �tre un observateur du mod�le et sera mise � jour � chaque
 * nouvelle g�n�ration des cellules.
 */
class VueInfoTour extends  JPanel implements Observer {

	private static final long serialVersionUID = 1L;
	private CModele modele;
	private JTextArea text;
	private JTextArea tourText;
	
	/** D�finition d'une taille (en pixels) pour l'affichage des cellules. */
	private final static int TAILLE = 40;
	
	public VueInfoTour(CModele modele) {
		this.modele = modele;
		text=new JTextArea(20, 10); 
		text.append("*********************");
		this.add(text);

	}
	
	/**
	 * L'interface [Observer] demande de fournir une m�thode [update], qui
	 * sera appel�e lorsque la vue sera notifi�e d'un changement dans le
	 * mod�le. Ici on se content de r�afficher toute la grille avec la m�thode
	 * pr�d�finie [repaint].
	 */
	public void update() { repaint(); }
	
	
	/**
	 * Les �l�ments graphiques comme [JPanel] poss�dent une m�thode
	 * [paintComponent] qui d�finit l'action � accomplir pour afficher cet
	 * �l�ment. On la red�finit ici pour lui confier l'affichage des cellules.
	 *
	 * La classe [Graphics] regroupe les �l�ments de style sur le dessin,
	 * comme la couleur actuelle.
	 */
	public void paintComponent(Graphics g) {
		super.repaint();
		/** Pour chaque cellule... */
		text.setText("");
		text.append(modele.infoTour());
	}

	
}


