
 public enum TypeCle { AIR, EAU, TERRE, FEU};