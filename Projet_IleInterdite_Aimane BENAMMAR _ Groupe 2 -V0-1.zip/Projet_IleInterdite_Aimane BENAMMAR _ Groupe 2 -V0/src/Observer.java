import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Application avec interface graphique.
 * Thibaut Balabonski, Universit� Paris-Sud.
 * Mat�riel p�dagogique li� au cours POGL, s�ance du 20 avril 2020.
 * 
 * Un principe directeur est la s�paration stricte des deux parties suivantes :
 *  - Le coeur de l'application, appel� le mod�le, o� est fait l'essentiel
 *    du travail.
 *  - L'interface utilisateur, appel�e la vue, qui � la fois montre des choses
 *    � l'utilisateur et lui fournit des moyens d'interagir.
 *
 * Notre cas d'�tude : le jeu de la vie de Conway.
 * Une grille bidimensionnelle de dimensions finies est peupl�e de cellules
 * pouvant �tre vivantes ou mortes. � chaque tour un nouvel �tat est calcul�
 * pour chaque cellule en fonction de l'�tat de ses voisines imm�diates.
 * Un bouton permet de passer au tour suivant (on dit aussi la g�n�ration
 * suivante).
 */

/**
 * Un lien entre vue et mod�le : les informations montr�es � l'utilisateur
 * refl�tent l'�tat du mod�le et doivent �tre maintenues � jour.
 * 
 * Pour r�aliser cette synchronisation, on peut suivre le sch�ma de conception
 * observateur/observ�, dont le principe est le suivant :
 *  - Un observateur (en l'occurrence la vue) est li� � un objet observ� et se
 *    met � jour pour refl�ter les changement de l'observ�.
 *  - Un observ� est li� � un ensemble d'objets observateurs et les notifie de
 *    tout changement de son propre �tat.
 *
 * Java fournit une interface [Observer] (observateur) et une classe
 * [Observable] (observ�) assurant cette jonction.
 * Voici une mani�re sommaire de les recoder.
 */

/**
 * Interface des objets observateurs.
 */ 
interface Observer {
    /**
     * Un observateur doit poss�der une m�thode [update] d�clenchant la mise �
     * jour.
     */
    public void update();
    /**
     * La version officielle de Java poss�de des param�tres pr�cisant le
     * changement qui a eu lieu.
     */
}