
public enum Situation {
	NORMALE, INONDEE, SUBMERGEE
}
