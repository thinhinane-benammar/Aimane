import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

/**
 * Classe pour notre contr�leur rudimentaire.
 * 
 * Le contr�leur impl�mente l'interface [ActionListener] qui demande
 * uniquement de fournir une m�thode [actionPerformed] indiquant la
 * r�ponse du contr�leur � la r�ception d'un �v�nement.
 */
class Controleur implements ActionListener {
	/**
	 * On garde un pointeur vers le mod�le, car le contr�leur doit
	 * provoquer un appel de m�thode du mod�le.
	 * Remarque : comme cette classe est interne, cette inscription
	 * explicite du mod�le est inutile. On pourrait se contenter de
	 * faire directement r�f�rence au mod�le enregistr� pour la classe
	 * englobante [VueCommandes].
	 */
	CModele modele;
	//int nbAction;
	//int tour ; //l indice du joueur qui doit jouer

	public Controleur(CModele modele) { 
		this.modele = modele; 
		//tour=0;
	}
	/**
	 * Action effectu�e � r�ception d'un �v�nement : appeler la
	 * m�thode [avance] du mod�le.
	 */
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());

		if (modele.partieGagnee()) {

			JOptionPane jop0 = new JOptionPane();
			JOptionPane.showMessageDialog(null, "Partie termin�e !!", "Termin�", JOptionPane.OK_OPTION);
		}else {
			if (modele.partiePerdue()) {

				JOptionPane jop0 = new JOptionPane();
				JOptionPane.showMessageDialog(null, "Partie termin�e avec Echec!!", "Oups", JOptionPane.ERROR_MESSAGE);
			}else {

				if (e.getActionCommand()=="fin de tour") {
					modele.nbAction=0;
					modele.inonde();
					modele.tour=(modele.tour+1)%modele.nb_joueurs;
				} else {

					if (modele.nbAction>=3) {

						JOptionPane jop3 = new JOptionPane();
						JOptionPane.showMessageDialog(null, "Le nombre d'action maximum pour un tour est 3, cliquer sur Fin de tour", "Erreur", JOptionPane.ERROR_MESSAGE);
					}
					else {
						if (e.getActionCommand()=="Droite")
						{
							modele.depl_droite(modele.tour);
							modele.nbAction++;
						}

						if (e.getActionCommand()=="Gauche") {
							modele.depl_gauche(modele.tour);
							modele.nbAction++;
						}

						if (e.getActionCommand()=="Haut") {
							modele.depl_haut(modele.tour);
							modele.nbAction++;
						}

						if (e.getActionCommand()=="Bas") {
							modele.nbAction++;
							modele.depl_bas(modele.tour);
						}

						if (e.getActionCommand()=="Assecher zone") {
							modele.nbAction++;
							int i=modele.getJoueur()[modele.tour].x;
							int j=modele.getJoueur()[modele.tour].y;
							modele.assecher(i, j);

							JOptionPane jop = new JOptionPane();
							String choix = jop.showInputDialog(null, "Veuillez choisir la case � secher: A, D, G, H, B !", JOptionPane.QUESTION_MESSAGE);
							switch (choix) {
							case "D":
								i=i+1;
								break;						
							case "G":
								i=i-1;
								break;
							case "H":
								j=j-1;
								break;
							case "B":
								j=j+1;
								break;
							default: 
								break;
							}
							modele.assecher(i, j);

						}


						if (e.getActionCommand()=="Recuperer artifact") {
							modele.nbAction++;
							modele.recupArtifact();

						}
						if (modele.partieGagnee()) {

							JOptionPane jop0 = new JOptionPane();
							JOptionPane.showMessageDialog(null, "Partie gagn�e !!", "Bravo", JOptionPane.INFORMATION_MESSAGE);
						}

						if (modele.partiePerdue()) {

							JOptionPane jop0 = new JOptionPane();
							JOptionPane.showMessageDialog(null, "Partie termin�e avec Echec!!", "Oups", JOptionPane.ERROR_MESSAGE);
						}


						if (e.getActionCommand()=="Assecher zone au choix") {

							JOptionPane jop = new JOptionPane();
							String choix = jop.showInputDialog(null, "Quelle zone voulez vous assecher x,y", JOptionPane.QUESTION_MESSAGE);
							int i= choix.indexOf(',');
							System.out.println(choix.substring(0, i)+"-----"+choix.substring(i+1));
							int x=Integer.parseInt(choix.substring(0, i));
							int y=Integer.parseInt(choix.substring(i+1));

							modele.assecherZone(x, y);
						}

						if (e.getActionCommand()=="Helicoptere") {

							JOptionPane jop = new JOptionPane();
							String choix = jop.showInputDialog(null, "Ou voulez vous allez x,y", JOptionPane.QUESTION_MESSAGE);
							int i= choix.indexOf(',');
							int x=Integer.parseInt(choix.substring(0, i));
							int y=Integer.parseInt(choix.substring(i+1));
							modele.deplHelico( x,y);
						}

					}
				}

			}
		}
	}
}
/** Fin du contr�leur. */