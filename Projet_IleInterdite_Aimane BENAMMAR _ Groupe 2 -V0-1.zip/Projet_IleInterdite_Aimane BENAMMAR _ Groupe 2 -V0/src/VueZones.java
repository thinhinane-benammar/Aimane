import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

/**
 * Une classe pour repr�senter la zone d'affichage des cellules.
 *
 * JPanel est une classe d'�l�ments graphiques, pouvant comme JFrame contenir
 * d'autres �l�ments graphiques.
 *
 * Cette vue va �tre un observateur du mod�le et sera mise � jour � chaque
 * nouvelle g�n�ration des cellules.
 */
class VueZones extends JPanel implements Observer {


	/** On maintient une r�f�rence vers le mod�le. */
	private CModele modele;
	/** D�finition d'une taille (en pixels) pour l'affichage des cellules. */
	private final static int TAILLE = 48;

	/** Constructeur. */
	public VueZones(CModele modele) {
		this.modele = modele;
		/** On enregistre la vue [this] en tant qu'observateur de [modele]. */
		modele.addObserver(this);
		/**
		 * D�finition et application d'une taille fixe pour cette zone de
		 * l'interface, calcul�e en fonction du nombre de cellules et de la
		 * taille d'affichage.
		 */
		Dimension dim = new Dimension(TAILLE*CModele.LARGEUR,
				TAILLE*CModele.HAUTEUR);
		this.setPreferredSize(dim);
	}

	/**
	 * L'interface [Observer] demande de fournir une m�thode [update], qui
	 * sera appel�e lorsque la vue sera notifi�e d'un changement dans le
	 * mod�le. Ici on se content de r�afficher toute la grille avec la m�thode
	 * pr�d�finie [repaint].
	 */
	public void update() { repaint(); }

	/**
	 * Les �l�ments graphiques comme [JPanel] poss�dent une m�thode
	 * [paintComponent] qui d�finit l'action � accomplir pour afficher cet
	 * �l�ment. On la red�finit ici pour lui confier l'affichage des cellules.
	 *
	 * La classe [Graphics] regroupe les �l�ments de style sur le dessin,
	 * comme la couleur actuelle.
	 */
	public void paintComponent(Graphics g) {
		super.repaint();
		/** Pour chaque cellule... */
		for(int i=1; i<=CModele.LARGEUR; i++) {
			for(int j=1; j<=CModele.HAUTEUR; j++) {
				/**
				 * ... Appeler une fonction d'affichage auxiliaire.
				 * On lui fournit les informations de dessin [g] et les
				 * coordonn�es du coin en haut � gauche.
				 */
				paint(g, modele.getZone(i, j), (i-1)*TAILLE, (j-1)*TAILLE);
			}

			for(int o=0; o<modele.nb_joueurs; o++) {
				paint(g,(modele.getJoueur()[o].x-1)*TAILLE, (modele.getJoueur()[o].y-1)*TAILLE);
			}
		}
	}
	/**
	 * Fonction auxiliaire de dessin d'une cellule.
	 * Ici, la classe [Cellule] ne peut �tre d�sign�e que par l'interm�diaire
	 * de la classe [CModele] � laquelle elle est interne, d'o� le type
	 * [CModele.Cellule].
	 * Ceci serait impossible si [Cellule] �tait d�clar�e priv�e dans [CModele].
	 */
	private void paint(Graphics g, Zone c, int x, int y) {
		Color prec;
		/** S�lection d'une couleur. */
		if (c.estNormale()) {
			//System.out.println("vert");
			g.setColor(Color.GREEN);		
		} else if (c.estInondee()){
			//System.out.println("bleu");
			g.setColor(Color.BLUE);
		} else if (c.estSubmergee() ){
			//System.out.println("rouge");
			g.setColor(Color.RED);
			/** Coloration d'un rectangle. */
		}else g.setColor(Color.GRAY);
		
		switch (c.type) {
		case HELIPORT:
			prec = g.getColor();
			g.setColor(Color.black);
			g.drawString("HEL", x, y);
			g.setColor(Color.yellow);
			break;
		case AIR:
			prec = g.getColor();
			g.setColor(Color.black);
			g.drawString("AIR", x, y);
			g.setColor(Color.yellow);
			break;
			
		case EAU:
			prec = g.getColor();
			g.setColor(Color.black);
			g.drawString("EAU", x, y);
			g.setColor(Color.yellow);
			break;
			
		case FEU:
			prec = g.getColor();
			g.setColor(Color.black);
			g.drawString("FEU", x, y);
			g.setColor(Color.yellow);
			break;

		case TERRE:
			prec = g.getColor();
			g.setColor(Color.black);
			g.drawString("TERRE", x, y);
			g.setColor(Color.yellow);
			break;
		}
		
		
		g.fillRect(x, y, TAILLE, TAILLE);
	}

	private void paint(Graphics g, int x, int y) {
		g.setColor(Color.BLACK);
		g.fillRect(x, y, TAILLE, TAILLE);
	}
}


