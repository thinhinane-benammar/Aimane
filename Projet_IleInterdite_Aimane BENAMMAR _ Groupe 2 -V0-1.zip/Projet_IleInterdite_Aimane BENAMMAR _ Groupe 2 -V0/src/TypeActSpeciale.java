
public enum TypeActSpeciale {
SacSable, Helicoptere
};
