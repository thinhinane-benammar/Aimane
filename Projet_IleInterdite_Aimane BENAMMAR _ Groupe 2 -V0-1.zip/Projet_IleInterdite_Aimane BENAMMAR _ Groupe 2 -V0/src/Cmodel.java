import java.util.ArrayList;
import java.util.Random;


/**
 * Le mod�le : le coeur de l'application.
 *
 * Le mod�le �tend la classe [Observable] : il va poss�der un certain nombre
 * d'observateurs (ici, un : la partie de la vue responsable de l'affichage)
 * et devra les pr�venir avec [notifyObservers] lors des modifications.
 * Voir la m�thode [avance()] pour cela.
 */

class CModele extends Observable {

	/** On fixe la taille de la grille. */
	public static final int HAUTEUR=10, LARGEUR=15;
	public static final int nb_joueurs=1;
	/** On stocke un tableau de cellules. */
	private Zone[][] Zones;
	/** On attache un joueur*/
	private Joueur[] joueurs;
	/**Artifacts r�cup�r�s*/
//	ArrayList<TypeCle> Artifacts;
	
	int nbAction;
	int tour ; //l indice du joueur qui doit jouer


	/** Construction : on initialise un tableau de cellules. */
	public CModele() {
		/**
		 * Pour �viter les probl�mes aux bords, on ajoute une ligne et une
		 * colonne de chaque c�t�, dont les cellules n'�volueront pas.
		 */ 
		tour=0; 
		nbAction=0;
		Zones = new Zone[LARGEUR+2][HAUTEUR+2];
		for(int i=0; i<LARGEUR+2; i++) {
			for(int j=0; j<HAUTEUR+2; j++) {
				Zones[i][j] = new Zone(this,i, j);
			}
		}
		init();
		placer_joueur();
	}

	/** Initialisation al�atoire des cellules */
	public void init() {
		for(int i=1; i<=LARGEUR; i++) {
			for(int j=1; j<=HAUTEUR; j++) {
				Random rand = new Random(); int nb = rand.nextInt(3);
				//if (nb==0)Zones[i][j].etat = Situation.NORMALE;
				//if(nb==1) Zones[i][j].etat = Situation.INONDEE;
				//if(nb==2) Zones[i][j].etat = Situation.SUBMERGEE;
				Zones[i][j].etat = Situation.NORMALE;
				Zones[i][j].type=TypeZone.ORDIANAIRE;
			}
		}

		//Placer les Zones sp�ciales
		int x, y;
		int[][] posArt = new int[5][2];
		TypeZone[] types =  {TypeZone.HELIPORT, TypeZone.AIR, TypeZone.EAU, TypeZone.FEU, TypeZone.TERRE};
		
		for (int i=0; i<types.length; i++) {
			do {
				Random rand = new Random(); 
				x = 2+rand.nextInt(LARGEUR-1); 
				y = 2+rand.nextInt(HAUTEUR-1);
			}while(posOccupe(x, y, posArt));
			
			System.out.println(types[i]+"======="+x+" , "+ y);
			Zones[x][y].type=types[i];
			posArt[i][0]=x;
			posArt[i][1]=y;
		}
	}

	/**Methode permettant de placer le joueur au d�but de la partie*/
	public void placer_joueur() {
		joueurs = new Joueur[nb_joueurs];
		int x, y;

		for (int i=0; i<nb_joueurs; i++) {
			do {
				Random rand = new Random(); 
				x = 1+rand.nextInt(LARGEUR-1); 
				y = 1+rand.nextInt(HAUTEUR-1); 

			} while (Zones[x][y].etat==Situation.SUBMERGEE);

			
			joueurs[i] =new Joueur(this, x, y);
		}
	}


	/** M�thode permettant d'inonder 3 zones al�atoirement */
	public void inonde() {
		int x, y;
		for (int i=0; i<3; i++) {

				Random rand = new Random(); 
				x = 1+rand.nextInt(LARGEUR-1); 
				y = 1+rand.nextInt(HAUTEUR-1); 
				
			System.out.println(x+","+y);
			if (Zones[x][y].etat==Situation.NORMALE)
				Zones[x][y].etat = Situation.INONDEE;
			else 
				Zones[x][y].etat = Situation.SUBMERGEE;
		}

		//attribuer 1/0 cl� aux joueurs
		for (int i=0; i<nb_joueurs; i++) {
			Random rand = new Random(); 
			x = rand.nextInt(6);
			switch(x) {
			case 0: 
				joueurs[i].cles.add(TypeCle.AIR);
				System.out.println("Joueur "+i+" artifact AIR ");
				break;
			case 1: 
				joueurs[i].cles.add(TypeCle.EAU);
				System.out.println("Joueur "+i+" artifact EAU ");
				break;
			case 2: 
				joueurs[i].cles.add(TypeCle.FEU);
				System.out.println("Joueur "+i+" artifact FEU ");
				break;
			case 3: 
				joueurs[i].cles.add(TypeCle.TERRE);
				System.out.println("Joueur "+i+" artifact TERRE ");
				break;
			case 4: 
				joueurs[i].actSpeciales.add(TypeActSpeciale.SacSable);
				System.out.println("Joueur "+i+" Sac Salbe ");
				break;
			case 5: 
				joueurs[i].actSpeciales.add(TypeActSpeciale.Helicoptere);
				System.out.println("Joueur "+i+" helicoptere ");
				break;

			}
		}
	}


	public void depl_haut(int i) {
		if (joueurs[i].y >1)
		joueurs[i].y --;
	}

	public void depl_bas(int i) {
		if (joueurs[i].y<HAUTEUR)
		joueurs[i].y ++;
	}

	public void depl_droite(int i) {
		if (joueurs[i].x<LARGEUR)
		joueurs[i].x ++;
	}

	public void depl_gauche(int i) {
		if (joueurs[i].x>1)
		joueurs[i].x --;	
	}

	public void assecher(int i, int j) {
		Zones[i][j].etat=Situation.NORMALE;
	}

	public void assecherZone( int x, int y) {
		Joueur j=joueurs[tour];
		for(int i=0; i<j.actSpeciales.size(); i++) {
			if(j.actSpeciales.get(i)==TypeActSpeciale.SacSable) {
				if(Zones[x][y].etat==Situation.INONDEE) {
					Zones[x][y].etat=Situation.NORMALE;
					j.actSpeciales.remove(i);
				}
			}
		}
	}
	
	public void deplHelico(int x, int y) {
		Joueur j=joueurs[tour];
		for(int i=0; i<j.actSpeciales.size(); i++) {
			if(j.actSpeciales.get(i)==TypeActSpeciale.Helicoptere) {
					j.x=x; 
					j.y=y;
					j.actSpeciales.remove(i);
			}
		}
	}
	
	public int possedeArtifact(Joueur j, TypeZone z) {
		for (int i=0; i<j.cles.size(); i++) {
			if (j.cles.get(i).toString() == z.toString())
				return i;
		}
		return -1;
	}

	/**M�thode recuperer artifact*/
	public void recupArtifact() {
		Joueur j=joueurs[tour];
		int x=joueurs[tour].x;
		int y=joueurs[tour].y;

		if (Zones[x][y].type !=TypeZone.HELIPORT && Zones[x][y].type !=TypeZone.ORDIANAIRE) {
			int t=possedeArtifact(j, Zones[x][y].type);
			if (t>=0) {
				j.Artifacts.add(j.cles.get(t));
				j.cles.remove(t);
				Zones[x][y].type=TypeZone.ORDIANAIRE;
				System.out.println("Artifact recupere ===="+x+" ,"+y);
			}
		}
	}

	/**
	 * Une m�thode pour renvoyer la cellule aux coordonn�es choisies (sera
	 * utilis�e par la vue).
	 */
	public Zone getZone(int x, int y) {
		return Zones[x][y];
	}

	public Joueur[] getJoueur() {
		return this.joueurs;
	}

	public Boolean posOccupe(int x, int y, int[][] tab) {
		for (int i=0; i<tab.length; i++)
		{
			if (tab[i][0]==x && tab[i][1]==y) return true;
		}

		return false;
	}
	
	public Boolean partieGagnee() {
		int nbArtifact=0;
		int x, y;
		for (int i=0; i<nb_joueurs; i++) {
			x=joueurs[i].x;
			y=joueurs[i].y;
			if (Zones[x][y].type!=TypeZone.HELIPORT) return false;
		}
		
		for (int i=0; i<nb_joueurs; i++) {
			nbArtifact= nbArtifact+joueurs[i].Artifacts.size();
		}
		if (nbArtifact<4) return false;

		return true;
	}
	
	
	public Boolean partiePerdue() {
		int x, y;
		for (int i=0; i<nb_joueurs; i++) {
			x=joueurs[i].x;
			y=joueurs[i].y;
			if (Zones[x][y].etat == Situation.SUBMERGEE) 
				return true;
		}
	return false;	
	
	}
	
	
    @Override
    public String toString() {
    	String res="";
    	for(int i=0; i<joueurs.length; i++) {
        	res=res+ "Joueur "+i;
    		res=res+ joueurs[i].toString();
    		res=res+"\n\n\n";
    	}
    	return res;

    }
    
    public String infoTour() {
    	String s="";
    	s=s+"C est le tour du joueur: " + tour+ "\n Nombre d action restante: "+ (3-nbAction)+"\n \n";
    	
    	return s;
    }

}