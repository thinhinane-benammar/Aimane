
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;

/**
 * Une classe pour repr�senter la zone contenant le bouton.
 *
 * Cette zone n'aura pas � �tre mise � jour et ne sera donc pas un observateur.
 * En revanche, comme la zone pr�c�dente, celle-ci est un panneau [JPanel].
 */
class VueCommandes extends JPanel {
    /**
     * Pour que le bouton puisse transmettre ses ordres, on garde une
     * r�f�rence au mod�le.
     */
    private CModele modele;

    /** Constructeur. */
    public VueCommandes(CModele modele) {
	this.modele = modele;
	
	this.setBackground(Color.DARK_GRAY);
	Dimension dim = new Dimension(30*CModele.LARGEUR,
			48*CModele.HAUTEUR);
	this.setPreferredSize(dim);
	
	this.setLayout(null);
	/**
	 * On cr�e un nouveau bouton, de classe [JButton], en pr�cisant le
	 * texte qui doit l'�tiqueter.
	 * Puis on ajoute ce bouton au panneau [this].
	 */

    //On d�finit le layout � utiliser sur le content pane
	
	
	JButton boutonDeplHaut = new JButton("Haut");
	boutonDeplHaut.setBounds(170, 30, 90, 30);
	this.add(boutonDeplHaut );
	
	
	JButton boutonDeplBas = new JButton("Bas");
	boutonDeplBas.setBounds(170, 110, 90, 30);
	this.add(boutonDeplBas);
	
	JButton boutonDeplDroite = new JButton("Droite");
	this.add(boutonDeplDroite);
	boutonDeplDroite.setBounds(230, 70, 90, 30);
	
	JButton boutonDeplGauche = new JButton("Gauche");
	boutonDeplGauche.setBounds(100, 70, 90, 30);
	this.add(boutonDeplGauche);
	
	JButton boutonAssecherZone = new JButton("Assecher zone");
	boutonAssecherZone.setBounds(50, 200, 180, 30);
	this.add(boutonAssecherZone);
	
	JButton boutonRecupArtifact = new JButton("Recuperer artifact");
	boutonRecupArtifact.setBounds(250, 200, 180, 30);
	this.add(boutonRecupArtifact);
	
	
	JButton boutonHelico = new JButton("Helicoptere");
	boutonHelico.setBounds(50, 250, 180, 30);
	this.add(boutonHelico);
	
	JButton boutonSacSable = new JButton("Assecher zone au choix");
	boutonSacSable.setBounds(250, 250, 180, 30);
	this.add(boutonSacSable);
	

	
	JButton boutonInonde = new JButton("fin de tour");
	boutonInonde.setBounds(50, 350, 380, 30);
	this.add(boutonInonde);


	/**
	 * Le bouton, lorsqu'il est cliqu� par l'utilisateur, produit un
	 * �v�nement, de classe [ActionEvent].
	 *
	 * On a ici une variante du sch�ma observateur/observ� : un objet
	 * impl�mentant une interface [ActionListener] va s'inscrire pour
	 * "�couter" les �v�nements produits par le bouton, et recevoir
	 * automatiquements des notifications.
	 * D'autres variantes d'auditeurs pour des �v�nements particuliers :
	 * [MouseListener], [KeyboardListener], [WindowListener].
	 *
	 * Cet observateur va enrichir notre sch�ma Mod�le-Vue d'une couche
	 * interm�diaire Contr�leur, dont l'objectif est de r�cup�rer les
	 * �v�nements produits par la vue et de les traduire en instructions
	 * pour le mod�le.
	 * Cette strate interm�diaire est potentiellement riche, et peut
	 * notamment traduire les m�mes �v�nements de diff�rentes fa�ons en
	 * fonction d'un �tat de l'application.
	 * Ici nous avons un seul bouton r�alisant une seule action, notre
	 * contr�leur sera donc particuli�rement simple. Cela n�cessite
	 * n�anmoins la cr�ation d'une classe d�di�e.
	 */	
	Controleur ctrl = new Controleur(modele);
	/** Enregistrement du contr�leur comme auditeur du bouton. */
	boutonInonde.addActionListener(ctrl);
	boutonDeplHaut.addActionListener(ctrl);
	boutonDeplBas.addActionListener(ctrl);
	boutonDeplDroite.addActionListener(ctrl);
	boutonDeplGauche.addActionListener(ctrl);
	boutonAssecherZone.addActionListener(ctrl);
	boutonRecupArtifact.addActionListener(ctrl);
	boutonSacSable.addActionListener(ctrl);
	boutonHelico.addActionListener(ctrl);
	


	/**
	 * Variante : une lambda-expression qui �vite de cr�er une classe
         * sp�cifique pour un contr�leur simplissime.
         *
         JButton boutonAvance = new JButton(">");
         this.add(boutonAvance);
         boutonAvance.addActionListener(e -> { modele.avance(); });
         *
         */

    }
}
/** Fin de la vue. */