import java.util.ArrayList;

public class Joueur {
    /** On conserve un pointeur vers la classe principale du mod�le. */
    private CModele modele;
    
    /** Coordonn�es du joueur */
    int x; int y;
	
    /** Cl�s maintenues par un joueur */
    ArrayList<TypeCle> cles;
	ArrayList<TypeCle> Artifacts;
	ArrayList<TypeActSpeciale> actSpeciales;
    
    public Joueur(CModele modele, int x, int y) {
        this.modele = modele;
        this.x = x; this.y = y;
        /**Un joueur peut avoir au maximum 4 cl�s*/
        cles=new ArrayList<TypeCle>();
		Artifacts = new ArrayList<TypeCle> ();
		actSpeciales=new ArrayList<TypeActSpeciale>();
    }

    @Override
    public String toString() {
    	String res="\n Cl�s obtenues : ";
    	for(int i=0; i<cles.size(); i++) {
    		res=res+"\n"+cles.get(i).name();
    	}
    	
    	
    	res=res + "\n\n Artifacts collect�s ";
    	for(int i=0; i<Artifacts.size(); i++) {
    		res=res+"\n"+Artifacts.get(i).name();
    	}
    	
    	res=res + "\n\n Actions sp�ciales: ";
    	for(int i=0; i<actSpeciales.size(); i++) {
    		res=res+"\n"+actSpeciales.get(i).name();
    	}
    	
    	return res;

    }
	
}
