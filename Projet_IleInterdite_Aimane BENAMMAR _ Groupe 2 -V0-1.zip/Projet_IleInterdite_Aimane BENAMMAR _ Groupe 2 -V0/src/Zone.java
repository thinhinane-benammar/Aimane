public class Zone {

    /** On conserve un pointeur vers la classe principale du mod�le. */
    private CModele modele;
    
    /** L'�tat d'une zone est: normal, inond� ou submerg�. */
    protected Situation etat;
	
    /** Coordonn�es des cellules pour pouvoir passer d'une cellule � une autre */
    int x; int y;
    
    /** Le type de la zone est: ordinaire, heliport ou zone artifact. */

    protected TypeZone type; 
    
    public Zone(CModele modele, int x, int y) {
        this.modele = modele;
        this.etat = Situation.NORMALE;
        this.x = x; this.y = y;
    }
    
    /** Un test � l'usage des autres classes (sera utilis� par la vue). */
    public boolean estNormale() {
        return (this.etat==Situation.NORMALE);
    }
    
    public boolean estInondee() {
        return (this.etat==Situation.INONDEE);
    }
	
    public boolean estSubmergee() {
        return (this.etat==Situation.SUBMERGEE);
    }
	
	
}
 